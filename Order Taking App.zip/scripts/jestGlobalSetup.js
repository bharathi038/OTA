const db = require('../config/db');

module.exports = async () => {
    //Connection Check
    // await db('tbl_items').select("*");    
};